#pragma once
#pragma warning(disable:4005)
#include <Windows.h>
#include <iostream>
#include <Psapi.h>
#include <vector>
#include <string>
#include <iostream>
#include <Dwmapi.h>
#include <dinput.h>
#include <tchar.h>
#include <d3d11.h>
#include "imgui/imgui.h"
#include "ImGui/imgui_internal.h"

using namespace std;

#define DIRECTINPUT_VERSION 0x0800
#define MAX_CLASSNAME 255
#define MAX_WNDNAME MAX_CLASSNAME


class GUI {
public:
	HWND hwnd = 0;
	bool setup();
	void render();
	void shutdown();
	static void restartUI();
	~GUI() {
		//shutdown();
	}
private:
	DWORD pid = 0;
	ImGuiContext *ctx;
	bool showConfig = false;

	ID3D11Device*            g_pd3dDevice = NULL;
	ID3D11DeviceContext*     g_pd3dDeviceContext = NULL;
	IDXGISwapChain*          g_pSwapChain = NULL;
	ID3D11RenderTargetView*  g_mainRenderTargetView = NULL;

	void CreateRenderTarget();
	void CleanupRenderTarget();
	HRESULT CreateDeviceD3D(HWND hWnd);
	void CleanupDeviceD3D();
	void clear();
	void draw();
	void show();




};